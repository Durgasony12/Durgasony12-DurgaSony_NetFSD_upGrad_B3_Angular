var allProducts = [];
$(document).ready(function() {
  loadProducts();
});
function loadProducts() {
  $.getJSON("data/products.json", function(data) {
    allProducts = data;
    showProducts(data);
  });
}
function showProducts(products) {
  var container = $("#productGrid");
  container.empty(); 
  for (var i = 0; i < products.length; i++) {
    var p = products[i];
    var cardHTML = `
      <div class="col-md-3 col-sm-6">
        <div class="product-card">
          <img src="${p.image}" alt="${p.name}" />
          <h5>${p.name}</h5>
          <p class="product-price">Rs. ${p.price}</p>
          <p style="font-size:0.85rem; color:gray;">${p.description}</p>
          <a href="product-details.html?id=${p.id}" class="btn btn-outline-secondary btn-sm w-100 mb-2">
            View Details
          </a>
          <button class="btn btn-warning btn-sm w-100" onclick="addToCart(${p.id})">
            Add to Cart
          </button>
        </div>
      </div>
    `;
    container.append(cardHTML);
  }
}

function addToCart(productId) {
  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  var product = null;
  for (var i = 0; i < allProducts.length; i++) {
    if (allProducts[i].id === productId) {
      product = allProducts[i];
    }
  }

  if (!product) return; 
  var found = false;
  for (var i = 0; i < cart.length; i++) {
    if (cart[i].id === productId) {
      cart[i].quantity = cart[i].quantity + 1; 
      found = true;
    }
  }
  if (!found) {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1
    });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  showToast(product.name + " added to cart!");
}
$("#searchInput").on("keyup", function() {
  var searchWord = $(this).val().toLowerCase();

  var filtered = [];
  for (var i = 0; i < allProducts.length; i++) {
    var name = allProducts[i].name.toLowerCase();
    if (name.includes(searchWord)) {
      filtered.push(allProducts[i]);
    }
  }

  showProducts(filtered);
});