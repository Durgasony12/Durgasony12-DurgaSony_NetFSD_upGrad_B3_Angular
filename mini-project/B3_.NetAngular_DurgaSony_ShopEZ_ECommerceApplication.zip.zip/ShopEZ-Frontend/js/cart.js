$(document).ready(function() {
  showCart();
});

function showCart() {
  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  var tbody = $("#cartTableBody");
  tbody.empty();

  if (cart.length === 0) {
    $("#cartContainer").html(`
      <div style="text-align:center; padding:60px;">
        <h4>Your cart is empty!</h4>
        <a href="products.html" class="btn btn-warning mt-3">Go Shopping</a>
      </div>
    `);
    return;
  }

  for (var i = 0; i < cart.length; i++) {
    var item = cart[i];
    var subtotal = item.price * item.quantity;

    var row = `
      <tr>
        <td>
          <img src="${item.image}" width="50" height="50" style="object-fit:cover; border-radius:6px;" />
          ${item.name}
        </td>
        <td>Rs. ${item.price}</td>
        <td>${item.quantity}</td>
        <td>Rs. ${subtotal}</td>
        <td>
          <button class="btn btn-danger btn-sm" onclick="removeItem(${item.id})">Remove</button>
        </td>
      </tr>
    `;
    tbody.append(row);
  }

  var total = calculateTotal(cart);
  $("#cartTotal").text("Rs. " + total);
  $("#cartItemCount").text(cart.length + " item(s)");
}

function calculateTotal(cart) {
  var total = 0;
  for (var i = 0; i < cart.length; i++) {
    total = total + (cart[i].price * cart[i].quantity);
  }
  return total;
}

// Remove an item from cart
function removeItem(productId) {
  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  var newCart = [];
  for (var i = 0; i < cart.length; i++) {
    if (cart[i].id !== productId) {
      newCart.push(cart[i]);
    }
  }

  localStorage.setItem("cart", JSON.stringify(newCart));
  updateCartCount();
  showCart();
  showToast("Item removed.");
}