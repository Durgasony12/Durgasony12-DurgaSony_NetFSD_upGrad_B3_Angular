$(document).ready(function() {
  showOrderSummary();
});

function showOrderSummary() {
  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  if (cart.length === 0) {
    alert("Cart is empty!");
    window.location.href = "products.html";
    return;
  }

  var list = $("#orderList");
  list.empty();

  var total = 0;

  for (var i = 0; i < cart.length; i++) {
    var item = cart[i];
    var sub = item.price * item.quantity;
    total = total + sub;

    list.append(`
      <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
        <span>${item.name} x${item.quantity}</span>
        <span>Rs. ${sub}</span>
      </div>
    `);
  }

  $("#orderTotal").text("Rs. " + (total + 99)); // +99 for shipping
}

$("#checkoutForm").on("submit", function(e) {
  e.preventDefault(); 
  var name    = $("#custName").val().trim();
  var email   = $("#custEmail").val().trim();
  var address = $("#custAddress").val().trim();
  if (name === "") {
    alert("Please enter your name.");
    return;
  }
  if (email === "") {
    alert("Please enter your email.");
    return;
  }
  if (address === "") {
    alert("Please enter your address.");
    return;
  }

  localStorage.removeItem("cart"); 
  updateCartCount();
  var orderId = "ORD" + Math.floor(Math.random() * 99999);
  $("#checkoutContainer").html(`
    <div class="success-msg">
      <h2>✅ Order Placed!</h2>
      <p>Thank you <strong>${name}</strong>!</p>
      <p>Your order ID is: <strong>${orderId}</strong></p>
      <a href="index.html" class="btn btn-warning mt-3">Back to Home</a>
    </div>
  `);
});