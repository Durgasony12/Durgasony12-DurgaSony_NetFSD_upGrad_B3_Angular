function updateCartCount() {
  var cart = JSON.parse(localStorage.getItem("cart")) || [];
  var totalItems = 0;
  for (var i = 0; i < cart.length; i++) {
    totalItems = totalItems + cart[i].quantity;
  }
  document.getElementById("cartCount").innerText = totalItems;
}
function showToast(message) {
  var toast = document.createElement("div");
  toast.innerText = message;
  toast.style.position = "fixed";
  toast.style.bottom = "20px";
  toast.style.right = "20px";
  toast.style.background = "#1a1a2e";
  toast.style.color = "white";
  toast.style.padding = "12px 20px";
  toast.style.borderRadius = "8px";
  toast.style.zIndex = "9999";
  toast.style.fontSize = "14px";
  document.body.appendChild(toast);
  setTimeout(function() {
    document.body.removeChild(toast);
  }, 3000);
}
updateCartCount();