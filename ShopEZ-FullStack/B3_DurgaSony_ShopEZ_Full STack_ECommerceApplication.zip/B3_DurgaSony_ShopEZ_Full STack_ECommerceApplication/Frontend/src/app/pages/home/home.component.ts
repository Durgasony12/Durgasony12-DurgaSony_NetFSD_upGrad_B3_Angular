import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  products: any[] = [
    { name: 'Laptop', price: 50000, category: 'Electronics', image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8' },
    { name: 'Headphones', price: 2000, category: 'Electronics', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500' },
    { name: 'Mobile', price: 15000, category: 'Electronics', image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9' },
    { name: 'Watch', price: 3000, category: 'Accessories', image: 'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b' },
    { name: 'Atomic Habits', price: 499, category: 'Books', image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794' },
    { name: 'The Alchemist', price: 299, category: 'Books', image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c' },
    { name: 'Bag', price: 1200, category: 'Accessories', image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa' },
  ];

  constructor(public auth: AuthService) {}
}