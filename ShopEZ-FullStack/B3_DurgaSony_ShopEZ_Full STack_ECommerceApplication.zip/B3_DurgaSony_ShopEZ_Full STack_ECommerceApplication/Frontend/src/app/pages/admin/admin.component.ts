import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { OrderService } from '../../services/order.service';
import { Product } from '../../models/product';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.component.html'
})
export class AdminComponent implements OnInit {

  activeTab = 'dashboard';

  // Products
  products: Product[] = [];
  newProduct: any = { name: '', description: '', price: null, stock: null, imageUrl: '', category: '' };
  editingProduct: Product | null = null;

  // Orders
  orders: any[] = [];

  message = '';
  error = '';

  constructor(
    private productService: ProductService,
    private orderService: OrderService
  ) {}

  ngOnInit(): void {
    this.loadProducts();
    this.loadOrders();
  }

  setTab(tab: string): void {
    this.activeTab = tab;
    this.message = '';
    this.error = '';
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe({
      next: (data) => this.products = data,
      error: () => this.error = '❌ Failed to load products'
    });
  }

  addProduct(): void {
    if (!this.newProduct.name || !this.newProduct.category) {
      this.error = '❌ Please fill in all required fields';
      return;
    }

    const productToSend = {
      name: this.newProduct.name,
      description: this.newProduct.description || '',
      price: Number(this.newProduct.price),
      stock: Number(this.newProduct.stock),
      imageUrl: this.newProduct.imageUrl || '',
      category: this.newProduct.category
    };

    this.productService.addProduct(productToSend).subscribe({
      next: (res: any) => {
        this.message = '✅ ' + res.message;
        this.error = '';
        this.newProduct = { name: '', description: '', price: null, stock: null, imageUrl: '', category: '' };
        this.loadProducts();
        setTimeout(() => this.message = '', 3000);
      },
      error: (err) => {
        this.error = '❌ Failed to add product (' + err.status + ')';
      }
    });
  }

  startEdit(product: Product): void {
    this.editingProduct = { ...product };
    this.message = '';
    this.error = '';
  }

  saveEdit(): void {
    if (!this.editingProduct) return;

    const productToSend = {
      productId: this.editingProduct.productId,
      name: this.editingProduct.name,
      description: this.editingProduct.description || '',
      price: Number(this.editingProduct.price),
      stock: Number(this.editingProduct.stock),
      imageUrl: this.editingProduct.imageUrl || '',
      category: this.editingProduct.category || ''
    };

    this.productService.updateProduct(this.editingProduct.productId, productToSend).subscribe({
      next: (res: any) => {
        this.message = '✅ ' + res.message;
        this.editingProduct = null;
        this.loadProducts();
        setTimeout(() => this.message = '', 3000);
      },
      error: (err) => {
        this.error = '❌ Failed to update product (' + err.status + ')';
      }
    });
  }

  cancelEdit(): void {
    this.editingProduct = null;
    this.message = '';
    this.error = '';
  }

  deleteProduct(id: number): void {
    this.productService.deleteProduct(id).subscribe({
      next: (res: any) => {
        this.message = '✅ ' + res.message;
        this.loadProducts();
        setTimeout(() => this.message = '', 3000);
      },
      error: () => {
        this.error = '❌ Failed to delete product';
      }
    });
  }

  loadOrders(): void {
    this.orderService.getAll().subscribe({
      next: (data) => this.orders = data,
      error: () => this.error = '❌ Failed to load orders'
    });
  }

  get totalProducts(): number { return this.products.length; }
  get totalOrders(): number { return this.orders.length; }
  get totalRevenue(): number {
    return this.orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  }
  get lowStockProducts(): number {
    return this.products.filter(p => p.stock < 10).length;
  }
}