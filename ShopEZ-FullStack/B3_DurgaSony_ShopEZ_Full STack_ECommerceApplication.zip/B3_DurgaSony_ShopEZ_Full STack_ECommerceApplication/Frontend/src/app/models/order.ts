 export interface CartItem {
  productId: number;
  quantity: number;
}

export interface OrderDTO {
  userId: number;
  cartItems: CartItem[];
}

export interface OrderItemResponse {
  orderItemId: number;
  productId: number;
  quantity: number;
  price: number;
}

export interface OrderResponse {
  orderId: number;
  userId: number;
  orderDate: string;
  totalAmount: number;
  orderItems: OrderItemResponse[];
}
