import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { RouterOutlet, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth.service';
import { CartService } from './services/cart.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterModule, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  cartCount = 0;
  isLoggedIn = false;
  userName = '';
  role = '';

  constructor(
    public auth: AuthService,
    private cartService: CartService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
  this.isLoggedIn = this.auth.isLoggedIn();
  this.userName = localStorage.getItem('username') || '';
  this.role = localStorage.getItem('role') || '';

  this.cartService.cartCount$.subscribe(count => {
    this.cartCount = count;
    this.isLoggedIn = this.auth.isLoggedIn();
    this.userName = localStorage.getItem('username') || '';
    this.role = localStorage.getItem('role') || '';
    this.cdr.detectChanges();
  });
}
  getUserName(): string {
  const token = this.auth.getToken();
  if (!token) return '';

  try {
    const payload = JSON.parse(atob(token.split('.')[1]));

    console.log("JWT Payload:", payload); 

    return payload.unique_name ||
           payload.name ||
           payload.Name ||
           payload.email ||
           'User';

  } catch {
    return 'User';
  }
}

  getUserRole(): string {
    const token = this.auth.getToken();
    if (!token) return '';

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.role || payload.Role || '';
    } catch {
      return '';
    }
  }

  logout(): void {
    this.auth.logout();
    this.isLoggedIn = false;
    this.userName = '';
    this.role = '';
    window.location.href = '/login';
  }
  
}