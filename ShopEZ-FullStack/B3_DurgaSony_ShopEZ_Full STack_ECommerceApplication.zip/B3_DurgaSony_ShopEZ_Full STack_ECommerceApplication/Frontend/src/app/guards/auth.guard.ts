import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {

    const token = localStorage.getItem('token');

    if (!token) {
      this.router.navigate(['/login']);
      return false;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));

      const role =
        payload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];

      const isAdmin = role === 'Admin';
      const requiresAdmin = route.data?.['requiresAdmin'];

      if (requiresAdmin && !isAdmin) {
        this.router.navigate(['/products']); 
        return false;
      }

      return true;

    } catch (e) {
      this.router.navigate(['/login']);
      return false;
    }
  }
}