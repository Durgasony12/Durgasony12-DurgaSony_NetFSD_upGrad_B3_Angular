import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from '../models/product';

export interface CartEntry {
  product: Product;
  quantity: number;
}

@Injectable({ providedIn: 'root' })
export class CartService {
  private items: CartEntry[] = [];
  private cartCountSubject = new BehaviorSubject<number>(0);
  cartCount$ = this.cartCountSubject.asObservable();

  add(product: Product): void {
    const existing = this.items.find(i => i.product.productId === product.productId);
    if (existing) {
      existing.quantity++;
    } else {
      this.items.push({ product, quantity: 1 });
    }
    this.cartCountSubject.next(this.items.length);
  }

  remove(productId: number): void {
    this.items = this.items.filter(i => i.product.productId !== productId);
    this.cartCountSubject.next(this.items.length);
  }

  increaseQty(productId: number): void {
    const existing = this.items.find(i => i.product.productId === productId);
    if (existing) {
      existing.quantity++;
    }
    this.cartCountSubject.next(this.items.length);
  }

  decreaseQty(productId: number): void {
    const existing = this.items.find(i => i.product.productId === productId);
    if (existing) {
      if (existing.quantity > 1) {
        existing.quantity--;
      } else {
        this.remove(productId);
      }
    }
    this.cartCountSubject.next(this.items.length);
  }

  getItems(): CartEntry[] {
    return this.items;
  }

  clear(): void {
    this.items = [];
    this.cartCountSubject.next(0);
  }

  getTotal(): number {
    return this.items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  }
}