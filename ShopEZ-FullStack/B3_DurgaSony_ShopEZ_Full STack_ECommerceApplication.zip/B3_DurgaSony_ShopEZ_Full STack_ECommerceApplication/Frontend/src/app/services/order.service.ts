import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private url = `${environment.apiUrl}/order`;

  constructor(private http: HttpClient) {}

  placeOrder(order: any): Observable<any> {
    return this.http.post(this.url, order);
  }

  getAll(): Observable<any[]> {
    return this.http.get<any[]>(this.url);
  }
  getOrdersByUser(userId: number): Observable<any[]> {
  return this.http.get<any[]>(`${this.url}/user/${userId}`);
}
}