import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../models/product';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private url = `${environment.apiUrl}/product`;
  private selectedProduct: any = null;

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${localStorage.getItem('token')}`,
      'Content-Type': 'application/json'
    });
  }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.url, {
      headers: this.getHeaders()
    });
  }

  getById(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.url}/${id}`, {
      headers: this.getHeaders()
    });
  }

  addProduct(product: any): Observable<any> {
    return this.http.post(this.url, product, {
      headers: this.getHeaders()
    });
  }

  updateProduct(id: number, product: any): Observable<any> {
    return this.http.put(`${this.url}/${id}`, product, {
      headers: this.getHeaders()
    });
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.url}/${id}`, {
      headers: this.getHeaders()
    });
  }

  setSelected(product: any): void {
    this.selectedProduct = product;
  }

  getSelected(): any {
    return this.selectedProduct;
  }
}