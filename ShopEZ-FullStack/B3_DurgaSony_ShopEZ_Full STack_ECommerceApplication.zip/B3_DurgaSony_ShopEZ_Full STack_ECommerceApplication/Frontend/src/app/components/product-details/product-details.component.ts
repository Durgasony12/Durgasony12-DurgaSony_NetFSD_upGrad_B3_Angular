import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent implements OnInit {
  product: any = null;
  message = '';
  loading = true;
  error = false;

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private cartService: CartService,
    private router: Router 
  ) {}

  ngOnInit(): void {
  const id = Number(this.route.snapshot.paramMap.get('id'));
  this.savedCategory = this.route.snapshot.queryParamMap.get('category') || 'All';

  const cached = this.productService.getSelected();
  if (cached && cached.productId === id) {
    this.product = cached;
    this.loading = false;
    return;
  }
  this.productService.getById(id).subscribe({
    next: (data: any) => {
      this.product = data;
      this.loading = false;
    },
    error: (err: any) => {
      this.loading = false;
      this.error = true;
    }
  });
}

  getName(): string {
    return this.product?.name || this.product?.Name || '';
  }

  getDesc(): string {
    return this.product?.description ||
           this.product?.Description ||
           'No description available';
  }

  getPrice(): number {
    return this.product?.price || this.product?.Price || 0;
  }

  getStock(): number {
    return this.product?.stock || this.product?.Stock || 0;
  }

  getImage(): string {
    const url = this.product?.imageUrl || this.product?.ImageUrl;
    return url || 'https://placehold.co/600x400?text=' + this.getName();
  }

  addToCart(): void {
    if (this.product) {
      this.cartService.add(this.product);
      this.message = 'Added to cart successfully!';
      setTimeout(() => this.message = '', 3000);
    }
  }

  savedCategory = 'All';

goBack(): void {
  const category = this.product?.category || this.product?.Category || this.savedCategory;
  this.router.navigate(['/products'], {
    queryParams: { category }
  });
}

  onImageError(event: any): void {
    event.target.src = 'https://placehold.co/600x400?text=No+Image';
  }
}