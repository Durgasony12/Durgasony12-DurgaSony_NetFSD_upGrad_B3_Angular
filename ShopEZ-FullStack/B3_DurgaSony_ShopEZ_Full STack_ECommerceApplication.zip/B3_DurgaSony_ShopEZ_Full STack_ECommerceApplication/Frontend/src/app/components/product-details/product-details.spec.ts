import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { ProductDetailsComponent } from './product-details.component';
Object.defineProperty(window, 'localStorage', {
  value: {
    getItem: () => 'dummy-token',
    setItem: () => {},
    removeItem: () => {},
    clear: () => {}
  }
});
describe('ProductDetails', () => {
  let component: ProductDetailsComponent;
  let fixture: ComponentFixture<ProductDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductDetailsComponent],
      providers: [provideRouter([]),provideHttpClient(),
                  provideHttpClientTesting()]
    }).compileComponents();

    fixture = TestBed.createComponent(ProductDetailsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should load product object', () => {
  expect(component).toBeTruthy();
  });
});