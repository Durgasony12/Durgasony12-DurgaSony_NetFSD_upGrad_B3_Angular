import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  email = '';
  password = '';
  error = '';
  loading = false;

  constructor(
    private auth: AuthService,
    private router: Router  
  ) {}

  login(): void {
    if (!this.email || !this.password) {
      this.error = 'Please enter email and password';
      return;
    }

    this.loading = true;
    this.error = '';

    this.auth.login(this.email, this.password).subscribe({
      next: (res) => {
  console.log("Login success", res);

  if (res.token) {
  this.auth.saveToken(res.token);
  localStorage.setItem('username', this.email.split('@')[0]);
  localStorage.setItem('role', res.role);
}

  this.router.navigate(['/products']).then(success => {
    console.log("Navigation success:", success);
  });
},
    });
  }
}