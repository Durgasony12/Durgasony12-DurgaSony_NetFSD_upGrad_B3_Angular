import { TestBed, ComponentFixture } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ProductListComponent } from './product-list.component';

Object.defineProperty(window, 'localStorage', {
  value: {
    getItem: () => 'dummy-token',
    setItem: () => {},
    removeItem: () => {},
    clear: () => {}
  }
});

describe('ProductListComponent', () => {
  let component: ProductListComponent;
  let fixture: ComponentFixture<ProductListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductListComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ProductListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have products array', () => {
  expect(component.products).toBeDefined();
  });
  it('should initialize component', () => {
  expect(component).toBeTruthy();
  });
});