import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { Product } from '../../models/product';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit {

  products: any[] = [];
  selectedCategory = '';
  sortOrder = 'none';
  categories: string[] = [];
  loading = true;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
  const cat = this.route.snapshot.queryParamMap.get('category');

  if (cat) {
    this.selectedCategory = cat;
  }

  this.productService.getProducts().subscribe({
    next: (data) => {
      console.log('PRODUCT-LIST ngOnInit data:', data);
      console.log('PRODUCT-LIST data length:', data.length);
      this.products = [...data];
      console.log('PRODUCT-LIST this.products after assign:', this.products.length);

      this.categories = [
        ...new Set(
          data
            .map(p => p.category)
            .filter((category): category is string => !!category)
        )
      ];
      this.loading = false; 
      this.cdr.detectChanges(); 
    },
    error: (err) => {
      console.error('Failed to load products:', err);
      this.loading = false; 
    }
  });
}

  onImageError(event: any) {
    event.target.src = 'https://placehold.co/400x300?text=No+Image';
  }

  addToCart(product: Product) {
    this.cartService.add(product);
  }

  viewDetails(product: Product) {
    this.productService.setSelected(product);
    this.router.navigate(['/product', product.productId], {
      queryParams: { category: this.selectedCategory }
    });
  }

  selectCategory(category: string) {
    this.selectedCategory = category;

    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { category },
      queryParamsHandling: 'merge'
    });
  }

  get filteredProducts(): any[] {
    let result = this.products;

    if (this.selectedCategory) {
      result = result.filter(
        p => p.category === this.selectedCategory
      );
    }

    if (this.sortOrder === 'low') {
      result = [...result].sort((a, b) => a.price - b.price);
    } else if (this.sortOrder === 'high') {
      result = [...result].sort((a, b) => b.price - a.price);
    }

    return result;
  }
}