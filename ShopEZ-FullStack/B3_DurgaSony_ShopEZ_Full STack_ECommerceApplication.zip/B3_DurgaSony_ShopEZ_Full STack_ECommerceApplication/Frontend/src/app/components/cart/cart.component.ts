import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { CartService, CartEntry } from '../../services/cart.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './cart.component.html'
})
export class CartComponent implements OnInit {
  items: CartEntry[] = [];

  constructor(
    private cartService: CartService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.items = this.cartService.getItems();
  }

  remove(productId: number): void {
    this.cartService.remove(productId);
    this.items = this.cartService.getItems();
  }

  increase(productId: number): void {
    this.cartService.increaseQty(productId);
    this.items = this.cartService.getItems();
  }

  decrease(productId: number): void {
    this.cartService.decreaseQty(productId);
    this.items = this.cartService.getItems();
  }

  getTotal(): number {
    return this.cartService.getTotal();
  }

  goToCheckout(): void {
    if (this.items.length === 0) {
      alert('Your cart is empty!');
      return;
    }
    this.router.navigate(['/checkout']);
  }
}