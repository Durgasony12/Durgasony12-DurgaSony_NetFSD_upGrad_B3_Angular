import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-my-orders',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './my-orders.component.html'
})
export class MyOrdersComponent implements OnInit {
  orders: any[] = [];
  error = '';
  loading = true;

  constructor(private orderService: OrderService) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(): void {
    const token = localStorage.getItem('token');

    if (!token) {
      this.error = 'User not logged in';
      this.loading = false;
      return;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      console.log('Token Payload:', payload);

      const userId =
        Number(payload.UserId) ||
        Number(payload.userId) ||
        Number(payload.id) ||
        Number(payload.sub) ||
        Number(payload.nameid) ||
        Number(
          payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier']
        );

      console.log('Extracted UserId:', userId);

      if (!userId || isNaN(userId)) {
        this.error = 'User ID not found in token';
        this.loading = false;
        return;
      }

      this.orderService.getOrdersByUser(userId).subscribe({
        next: (data) => {
          this.orders = data;
          this.loading = false;
        },
        error: (err) => {
          console.error(err);
          this.error = 'Failed to load orders';
          this.loading = false;
        }
      });

    } catch (err) {
      console.error(err);
      this.error = 'Failed to decode token';
      this.loading = false;
    }
  }
  
}