import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './checkout.component.html'
})
export class CheckoutComponent implements OnInit {
  items: any[] = [];
  message = '';
  error = '';
  loading = false;
  orderPlaced = false;

  deliveryForm = {
    fullName: '',
    phone: '',
    address: '',
    city: '',
    pincode: ''
  };

  constructor(
    public cartService: CartService,
    private orderService: OrderService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.items = this.cartService.getItems();
  }

  getTotal(): number {
    return this.cartService.getTotal();
  }

  getUserId(): number {
    const token = localStorage.getItem('token');
    if (!token) return 1;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return parseInt(String(
        payload.UserId ||
        payload.userId ||
        payload.nameid ||
        payload.sub ||
        payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'] ||
        1
      ), 10);
    } catch (e) {
      return 1;
    }
  }

  isFormValid(): boolean {
    return !!(
      this.deliveryForm.fullName &&
      this.deliveryForm.phone &&
      this.deliveryForm.address &&
      this.deliveryForm.city &&
      this.deliveryForm.pincode
    );
  }

  placeOrder(): void {
    if (!localStorage.getItem('token')) {
      this.error = 'Please login first!';
      setTimeout(() => this.router.navigate(['/login']), 2000);
      return;
    }

    if (this.items.length === 0) {
      this.error = 'Your cart is empty!';
      return;
    }

    if (!this.isFormValid()) {
      this.error = 'Please fill in all delivery details!';
      return;
    }

    const userId = parseInt(String(this.getUserId()), 10) || 1;

    const order = {
      UserId: userId,
      CartItems: this.items.map(i => ({
        ProductId: Number(i.product.productId),
        Quantity: Number(i.quantity)
      }))
    };

    this.loading = true;
    this.error = '';

    this.orderService.placeOrder(order).subscribe({
      next: (res: any) => {
        this.loading = false;
        this.orderPlaced = true;
        this.cdr.detectChanges();
        this.cartService.clear();
        this.items = [];
      },
      error: (err: any) => {
        this.loading = false;
        if (err.status === 401) {
          this.error = 'Session expired. Please login again.';
        } else if (err.status === 400) {
          this.error = 'Invalid order: ' + JSON.stringify(err.error?.errors || err.error);
        } else if (err.status === 0) {
          this.error = 'Cannot connect to server.';
        } else {
          this.error = `Order failed (${err.status}). Please try again.`;
        }
      }
    });
  }

  continueShopping(): void {
    this.router.navigate(['/products']);
  }

  goToProducts(): void {
    this.router.navigate(['/products']);
  }
}