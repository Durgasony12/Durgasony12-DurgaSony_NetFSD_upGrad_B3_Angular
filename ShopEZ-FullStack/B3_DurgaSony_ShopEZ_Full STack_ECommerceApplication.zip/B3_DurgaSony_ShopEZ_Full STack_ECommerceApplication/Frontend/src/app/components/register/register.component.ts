import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  message = '';
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  register(): void {
    if (!this.name || !this.email || !this.password) {
      this.error = "Please enter all details";
      return;
    }

    const user = {
      name: this.name,
      email: this.email,
      password: this.password
    };

    this.auth.register(user).subscribe({
      next: () => {
        this.message = 'Registered successfully! Please login.';
        this.error = '';
        setTimeout(() => this.router.navigate(['/login']), 2000);
      },
      error: (err) => {
      console.log("FULL ERROR:", err);
      console.log("VALIDATION ERRORS:", err.error?.errors);

      if (err.error?.errors) {
          const allErrors = Object.values(err.error.errors).flat();
          this.error = allErrors.join(', ');
        } else {
          this.error = 'Registration failed';
        }
      }
    });
  }
}