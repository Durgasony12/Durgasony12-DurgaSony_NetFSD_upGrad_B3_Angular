﻿using shopez_OrderService.DTOs;
using shopez_OrderService.Models;
using shopez_OrderService.Repositories;
namespace shopez_OrderService.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repo;
        private readonly ProductClient _productClient;
        private readonly IHttpContextAccessor _httpContext;

        public OrderService(
            IOrderRepository repo,
            ProductClient productClient,
            IHttpContextAccessor httpContext)
        {
            _repo = repo;
            _productClient = productClient;
            _httpContext = httpContext;
        }

        // CREATE ORDER
        public async Task<OrderResponseDTO?> CreateOrder(OrderDTO dto)
        {
            if (dto == null || dto.CartItems == null || dto.CartItems.Count == 0)
                return null;

            var token = _httpContext.HttpContext?.Request.Headers["Authorization"].ToString();

            if (string.IsNullOrEmpty(token))
                return null;

            var order = new Order
            {
                UserId = dto.UserId,
                OrderDate = DateTime.Now,
                OrderItems = new List<OrderItem>()
            };

            foreach (var item in dto.CartItems)
            {
                if (item.Quantity <= 0)
                    return null;

                var product = await _productClient.GetProduct(item.ProductId, token);

                if (product == null)
                    return null;

                order.OrderItems.Add(new OrderItem
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Price = product.Price 
                });
            }

            order.TotalAmount = order.OrderItems
                .Sum(i => i.Price * i.Quantity);

            await _repo.AddAsync(order);

            foreach (var item in dto.CartItems)
            {
                await _productClient.ReduceStock(item.ProductId, item.Quantity, token);
            }

            return MapToResponse(order);
        }

        //GET ALL
        public async Task<List<OrderResponseDTO>> GetAllOrders()
        {
            var orders = await _repo.GetAllAsync();

            return orders.Select(o => MapToResponse(o)).ToList();
        }

        public async Task<OrderResponseDTO?> GetOrderById(int id)
        {
            var order = await _repo.GetByIdAsync(id);

            if (order == null)
                return null;

            return MapToResponse(order);
        }
        public async Task<List<OrderResponseDTO>> GetOrdersByUserId(int userId)
        {
            var orders = await _repo.GetAllAsync();
            return orders
                .Where(o => o.UserId == userId)
                .Select(o => MapToResponse(o))
                .ToList();
        }

        private OrderResponseDTO MapToResponse(Order order)
        {
            return new OrderResponseDTO
            {
                OrderId = order.OrderId,
                UserId = order.UserId,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                OrderItems = order.OrderItems.Select(i => new OrderItemResponseDTO
                {
                    OrderItemId = i.OrderItemId,
                    ProductId = i.ProductId,
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList()
            };
        }
    }
}
