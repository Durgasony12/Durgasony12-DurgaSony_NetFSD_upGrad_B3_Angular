﻿using shopez_OrderService.DTOs;
namespace shopez_OrderService.Services
{
    public interface IOrderService
    {
        Task<OrderResponseDTO?> CreateOrder(OrderDTO dto);
        Task<List<OrderResponseDTO>> GetAllOrders();
        Task<OrderResponseDTO?> GetOrderById(int id);
        Task<List<OrderResponseDTO>> GetOrdersByUserId(int userId);
    }
}
