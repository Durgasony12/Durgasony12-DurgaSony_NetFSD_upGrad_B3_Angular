﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using shopez_OrderService.DTOs;

namespace shopez_OrderService.Services
{
    public class ProductClient
    {
        private readonly HttpClient _http;

        public ProductClient(HttpClient http, IConfiguration config)
        {
            _http = http;
            _http.BaseAddress = new Uri(config["Services:ProductService"]);
        }

        public async Task<ProductDTO?> GetProduct(int productId, string token)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"api/Product/{productId}");

            request.Headers.Authorization =
                new AuthenticationHeaderValue("Bearer", token.Replace("Bearer ", ""));

            var response = await _http.SendAsync(request);

            if (!response.IsSuccessStatusCode)
                return null;

            return await response.Content.ReadFromJsonAsync<ProductDTO>();
        }

        public async Task ReduceStock(int productId, int quantity, string token)
        {
            var request = new HttpRequestMessage(
                HttpMethod.Patch,
                $"api/Product/{productId}/reduce-stock?quantity={quantity}"
            );

            request.Headers.Authorization =
                new AuthenticationHeaderValue("Bearer", token.Replace("Bearer ", ""));

            await _http.SendAsync(request);
        }
    }
}