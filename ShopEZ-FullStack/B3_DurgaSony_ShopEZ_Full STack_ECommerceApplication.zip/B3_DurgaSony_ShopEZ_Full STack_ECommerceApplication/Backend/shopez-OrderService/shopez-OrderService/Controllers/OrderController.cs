﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using shopez_OrderService.DTOs;
using shopez_OrderService.Services;
namespace shopez_OrderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _service;

        public OrderController(IOrderService service)
        {
            _service = service;
        }
        //CREATE ORDER
        [HttpPost]
        public async Task<IActionResult> CreateOrder([FromBody] OrderDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _service.CreateOrder(dto);

            if (result == null)
                return BadRequest(new { message = "Invalid order or product" });

            return Ok(result);
        }
        //GET ALL ORDERS
       
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var orders = await _service.GetAllOrders();
            return Ok(orders);
        }
        // GET ORDER BY ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var order = await _service.GetOrderById(id);

            if (order == null)
                return NotFound(new { message = "Order not found" });

            return Ok(order);
        }
        [HttpGet("user/{userId}")]
        
        public async Task<IActionResult> GetByUserId(int userId)
        {
            var orders = await _service.GetOrdersByUserId(userId);
            return Ok(orders);
        }

    }
}
