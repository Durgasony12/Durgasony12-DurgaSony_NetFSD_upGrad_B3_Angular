﻿using System.ComponentModel.DataAnnotations;
namespace shopez_OrderService.Models
{
    public class Order
    {
        public int OrderId { get; set; }

        [Required]
        public int UserId { get; set; }

        public DateTime OrderDate { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Total amount cannot be negative")]
        public decimal TotalAmount { get; set; }


        public ICollection<OrderItem>? OrderItems { get; set; }
    }
}
