﻿using shopez_OrderService.Models;
namespace shopez_OrderService.Repositories
{
    public interface IOrderRepository
    {
        Task AddAsync(Order order);
        Task<List<Order>> GetAllAsync();
        Task<Order?> GetByIdAsync(int id);
    }
}
