﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using Shopez_AuthService.DTO;
using Shopez_AuthService.Models;
using Shopez_AuthService.Services;

namespace Shopez_AuthService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;
        private readonly ApplicationDbContext _context;

        public AuthController(AuthService authService, ApplicationDbContext context)
        {
            _authService = authService;
            _context = context;
        }

        //REGISTER
        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDTO dto)
        {
            if (_context.Users.Any(u => u.Email == dto.Email))
                return BadRequest("Email already registered");

            var user = new User
            {
                Name = dto.Name,
                Email = dto.Email,
                Password = dto.Password,
                Role = "User"
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "User registered successfully"
            });
        }

        //LOGIN
        [HttpPost("login")]
        public IActionResult Login(LoginDTO dto)
        {
            var userObj = _context.Users.FirstOrDefault(u =>
                u.Email == dto.Email &&
                u.Password == dto.Password);

            if (userObj == null)
                return Unauthorized("Invalid email or password");

            string token = _authService.GenerateJSONWebToken(userObj);

            return Ok(new
            {
                message = "Login successful",
                token = token
            });
        }
    }
}