﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.DTOs;
using ProductService.Services;

namespace ProductService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductController(IProductService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _service.GetAllProductsAsync();
            return Ok(products); 
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var product = await _service.GetProductByIdAsync(id);

            if (product == null)
                return NotFound(new { message = "Product not found" }); 

            return Ok(product); 
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] ProductDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _service.AddProductAsync(dto);

            if (!result)
                return BadRequest(new { message = "Invalid product data" });

            return Ok(new { message = "Product created successfully" }); 
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] ProductDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _service.UpdateProductAsync(id, dto);

            if (!result)
                return NotFound(new { message = "Product not found" });

            return Ok(new { message = "Product updated successfully" });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _service.DeleteProductAsync(id);

            if (!result)
                return NotFound(new { message = "Product not found" });

            return Ok(new { message = "Product deleted successfully" });
        }
        [HttpPatch("{id}/reduce-stock")]
        public async Task<IActionResult> ReduceStock(int id, [FromQuery] int quantity)
        {
            if (quantity <= 0)
                return BadRequest(new { message = "Quantity must be greater than zero" });

            var result = await _service.ReduceStockAsync(id, quantity);

            if (!result)
                return BadRequest(new { message = "Insufficient stock or product not found" });

            return Ok(new { message = "Stock reduced successfully" });
        }
    }
}