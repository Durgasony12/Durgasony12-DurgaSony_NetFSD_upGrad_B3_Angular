﻿using ProductService.DTOs;
using ProductService.Models;
using ProductService.Repositories;

namespace ProductService.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _repo;

        public ProductService(IProductRepository repo)
        {
            _repo = repo;
        }
        public async Task<List<Product>> GetAllProductsAsync()
        {
            return await _repo.GetAllAsync();
        }

        public async Task<Product?> GetProductByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task<bool> AddProductAsync(ProductDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Name) || dto.Price <= 0)
                return false;

            var product = new Product
            {
                Name = dto.Name,
                Description = dto.Description,
                Price = dto.Price,
                ImageUrl = dto.ImageUrl,
                Stock = dto.Stock,
                Category = dto.Category
            };

            await _repo.AddAsync(product);
            return true;
        }

        public async Task<bool> UpdateProductAsync(int id, ProductDTO dto)
        {
            var product = await _repo.GetByIdAsync(id);
            if (product == null)
                return false;

            product.Name = dto.Name;
            product.Description = dto.Description;
            product.Price = dto.Price;
            product.ImageUrl = dto.ImageUrl;
            product.Stock = dto.Stock;
            product.Category = dto.Category;

            await _repo.UpdateAsync(product);
            return true;
        }

        public async Task<bool> DeleteProductAsync(int id)
        {
            var product = await _repo.GetByIdAsync(id);
            if (product == null)
                return false;

            await _repo.DeleteAsync(id);
            return true;
        }
        public async Task<bool> ReduceStockAsync(int id, int quantity)
        {
            var product = await _repo.GetByIdAsync(id);

            if (product == null)
                return false;

            if (product.Stock < quantity)
                return false;

            product.Stock -= quantity;

            await _repo.UpdateAsync(product);
            return true;
        }
    }
}
