﻿using ProductService.Models;
using ProductService.DTOs;
namespace ProductService.Services
{
    public interface IProductService
    {
        Task<List<Product>> GetAllProductsAsync();
        Task<Product?> GetProductByIdAsync(int id);
        Task<bool> AddProductAsync(ProductDTO dto);
        Task<bool> UpdateProductAsync(int id, ProductDTO dto);
        Task<bool> DeleteProductAsync(int id);
        Task<bool> ReduceStockAsync(int id, int quantity);
    }
}
