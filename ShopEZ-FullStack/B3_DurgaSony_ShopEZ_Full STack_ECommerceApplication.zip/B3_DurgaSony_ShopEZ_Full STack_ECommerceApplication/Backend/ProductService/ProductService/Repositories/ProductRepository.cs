﻿using Dapper;
using Microsoft.Data.SqlClient;
using ProductService.Models;

namespace ProductService.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly IConfiguration _config;

        public ProductRepository(IConfiguration config)
        {
            _config = config;
        }

        private SqlConnection Connection =>
            new SqlConnection(
                _config.GetConnectionString("DefaultConnection"));

        //GET ALL PRODUCTS
        public async Task<List<Product>> GetAllAsync()
        {
            using var connection = Connection;

            string sql = "SELECT * FROM Products";

            var products = await connection.QueryAsync<Product>(sql);

            return products.ToList();
        }

        // GET PRODUCT BY ID
        public async Task<Product?> GetByIdAsync(int id)
        {
            using var connection = Connection;

            string sql =
                "SELECT * FROM Products WHERE ProductId = @ProductId";

            return await connection.QueryFirstOrDefaultAsync<Product>(
                sql,
                new { ProductId = id });
        }

        //ADD PRODUCT
        public async Task AddAsync(Product product)
        {
            using var connection = Connection;

            string sql = @"
                INSERT INTO Products
                (Name, Description, Price, ImageUrl, Stock,Category)

                VALUES
                (@Name, @Description, @Price, @ImageUrl, @Stock,@Category)";

            await connection.ExecuteAsync(sql, product);
        }

        // UPDATE PRODUCT
        public async Task UpdateAsync(Product product)
        {
            using var connection = Connection;

            string sql = @"
                UPDATE Products
                SET
                    Name = @Name,
                    Description = @Description,
                    Price = @Price,
                    ImageUrl = @ImageUrl,
                    Stock = @Stock,
                    Category = @Category
                WHERE ProductId = @ProductId";

            await connection.ExecuteAsync(sql, product);
        }

        //DELETE PRODUCT
        public async Task DeleteAsync(int id)
        {
            using var connection = Connection;

            string sql =
                "DELETE FROM Products WHERE ProductId = @ProductId";

            await connection.ExecuteAsync(
                sql,
                new { ProductId = id });
        }
    }
}