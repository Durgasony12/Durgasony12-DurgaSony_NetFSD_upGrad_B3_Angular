﻿using Microsoft.Extensions.Configuration;
using Shopez_AuthService.Models;
using Shopez_AuthService.Services;
using Xunit;

namespace AuthService.Tests
{
    public class AuthServiceTests
    {
        private readonly Shopez_AuthService.Services.AuthService _authService;

        public AuthServiceTests()
        {
            var config = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string>
                {
                    { "Jwt:Key", "ThisIsASecretKeyForTestingPurposes123!" },
                    { "Jwt:Issuer", "ShopEZ" },
                    { "Jwt:Audience", "ShopEZUsers" }
                })
                .Build();

            _authService = new Shopez_AuthService.Services.AuthService(config);
        }

        [Fact]
        public void GenerateJSONWebToken_ValidUser_ReturnsToken()
        {
            var user = new User
            {
                UserId = 1,
                Name = "Sony",
                Email = "sony@test.com",
                Password = "password123",
                Role = "User"
            };

            var token = _authService.GenerateJSONWebToken(user);

            Assert.NotNull(token);
            Assert.NotEmpty(token);
        }

        [Fact]
        public void GenerateJSONWebToken_ReturnsValidJwtFormat()
        {
            var user = new User
            {
                UserId = 1,
                Name = "Sony",
                Email = "sony@test.com",
                Password = "password123",
                Role = "User"
            };

            var token = _authService.GenerateJSONWebToken(user);

            var parts = token.Split('.');
            Assert.Equal(3, parts.Length);
        }

        [Fact]
        public void GenerateJSONWebToken_AdminUser_ReturnsToken()
        {
            var user = new User
            {
                UserId = 2,
                Name = "Admin",
                Email = "admin@test.com",
                Password = "admin123",
                Role = "Admin"
            };

            var token = _authService.GenerateJSONWebToken(user);

            Assert.NotNull(token);
            Assert.NotEmpty(token);
        }

        [Fact]
        public void GenerateJSONWebToken_TwoDifferentUsers_ReturnsDifferentTokens()
        {
            var user1 = new User { UserId = 1, Name = "Sony", Email = "sony@test.com", Password = "pass123", Role = "User" };
            var user2 = new User { UserId = 2, Name = "Admin", Email = "admin@test.com", Password = "admin123", Role = "Admin" };

            var token1 = _authService.GenerateJSONWebToken(user1);
            var token2 = _authService.GenerateJSONWebToken(user2);

            Assert.NotEqual(token1, token2);
        }

        [Fact]
        public void GenerateJSONWebToken_ReturnsNonExpiredToken()
        {
            var user = new User
            {
                UserId = 1,
                Name = "Sony",
                Email = "sony@test.com",
                Password = "password123",
                Role = "User"
            };

            var token = _authService.GenerateJSONWebToken(user);
            var handler = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler();
            var jwtToken = handler.ReadJwtToken(token);

            Assert.True(jwtToken.ValidTo > DateTime.UtcNow);
        }
    }
}