﻿using Moq;
using ProductService.DTOs;
using ProductService.Models;
using ProductService.Repositories;
using ProductService.Services;
using Xunit;

namespace ProductService.Tests
{
    public class ProductServiceTests
    {
        private readonly Mock<IProductRepository> _mockRepo;
        private readonly ProductService.Services.ProductService _service;

        public ProductServiceTests()
        {
            _mockRepo = new Mock<IProductRepository>();
            _service = new ProductService.Services.ProductService(_mockRepo.Object);
        }

        [Fact]
        public async Task GetAllProductsAsync_ReturnsAllProducts()
        {
            var fakeProducts = new List<Product>
            {
                new Product { ProductId = 1, Name = "Laptop", Price = 50000, Category = "Electronics", Stock = 10 },
                new Product { ProductId = 2, Name = "Mobile", Price = 15000, Category = "Electronics", Stock = 20 }
            };
            _mockRepo.Setup(r => r.GetAllAsync()).ReturnsAsync(fakeProducts);

            var result = await _service.GetAllProductsAsync();

            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
        }

        [Fact]
        public async Task GetProductByIdAsync_ReturnsCorrectProduct()
        {
            var fakeProduct = new Product { ProductId = 1, Name = "Laptop", Price = 50000, Category = "Electronics", Stock = 10 };
            _mockRepo.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(fakeProduct);

            var result = await _service.GetProductByIdAsync(1);

            Assert.NotNull(result);
            Assert.Equal("Laptop", result.Name);
        }

        [Fact]
        public async Task GetProductByIdAsync_InvalidId_ReturnsNull()
        {
            _mockRepo.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Product?)null);

            var result = await _service.GetProductByIdAsync(99);

            Assert.Null(result);
        }

        [Fact]
        public async Task AddProductAsync_ValidProduct_ReturnsTrue()
        {
            var dto = new ProductDTO
            {
                Name = "Laptop",
                Price = 50000,
                Stock = 10,
                Category = "Electronics"
            };
            _mockRepo.Setup(r => r.AddAsync(It.IsAny<Product>())).Returns(Task.CompletedTask);

            var result = await _service.AddProductAsync(dto);

            Assert.True(result);
        }

        [Fact]
        public async Task AddProductAsync_EmptyName_ReturnsFalse()
        {
            var dto = new ProductDTO { Name = "", Price = 50000, Stock = 10 };

            var result = await _service.AddProductAsync(dto);

            Assert.False(result);
        }

        [Fact]
        public async Task AddProductAsync_InvalidPrice_ReturnsFalse()
        {
            var dto = new ProductDTO { Name = "Laptop", Price = 0, Stock = 10 };

            var result = await _service.AddProductAsync(dto);

            Assert.False(result);
        }

        [Fact]
        public async Task UpdateProductAsync_ValidId_ReturnsTrue()
        {
            var existing = new Product { ProductId = 1, Name = "Laptop", Price = 50000, Category = "Electronics", Stock = 10 };
            var dto = new ProductDTO { Name = "Laptop Pro", Price = 60000, Stock = 5, Category = "Electronics" };

            _mockRepo.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(existing);
            _mockRepo.Setup(r => r.UpdateAsync(It.IsAny<Product>())).Returns(Task.CompletedTask);

            var result = await _service.UpdateProductAsync(1, dto);

            Assert.True(result);
        }

        [Fact]
        public async Task UpdateProductAsync_InvalidId_ReturnsFalse()
        {
            _mockRepo.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Product?)null);

            var result = await _service.UpdateProductAsync(99, new ProductDTO());

            Assert.False(result);
        }

        [Fact]
        public async Task DeleteProductAsync_ValidId_ReturnsTrue()
        {
            var existing = new Product { ProductId = 1, Name = "Laptop", Price = 50000, Stock = 10 };
            _mockRepo.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(existing);
            _mockRepo.Setup(r => r.DeleteAsync(1)).Returns(Task.CompletedTask);

            var result = await _service.DeleteProductAsync(1);

            Assert.True(result);
        }

        [Fact]
        public async Task DeleteProductAsync_InvalidId_ReturnsFalse()
        {
            _mockRepo.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Product?)null);

            var result = await _service.DeleteProductAsync(99);

            Assert.False(result);
        }
    }
}